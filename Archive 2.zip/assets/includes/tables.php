<?php
define('T_USERS', 'users');
define('T_SESSIONS', 'sessions');
define('T_CONFIG', 'config');
define('T_LANGS', 'langs');
define('T_BANNED_IPS', 'banned');
define('T_TERMS', 'terms');
define('T_JOBS', 'jobs');
define('T_JOB_DATA', 'job_data');
define('T_APP_SESSIONS', 'apps_sessions');
define('T_BOOK', 'book');
define('T_LESSONS', 'lessons');
define('T_QUIZ', 'quiz');
define('T_QUESTIONSTR', 'questions_tr');
define('T_CHOICE', 'choice');
define('T_USER_LESSONS', 'user_lessons');
