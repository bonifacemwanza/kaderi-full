<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require __DIR__ . '/../../assets/import/PHPMailer-Master/vendor/autoload.php';
$mail = new PHPMailer;