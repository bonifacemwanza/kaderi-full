<?php
$kd->page_url_   = $kd->config->site_url.'/lesson';
$kd->title       = __('lesson') . ' | ' . $kd->config->title;
$kd->page        = "lesson";
$kd->description = $kd->config->description;
$kd->keyword     = @$kd->config->keyword;
$kd->content     = LoadPage('courses/single_lesson', array(
   'LESSON_GRID' => LoadPage('courses/lesson_grid')
));