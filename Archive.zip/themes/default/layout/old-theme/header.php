
		<div id="loader">
			<div class="loader-container">
					<img src="images/site.gif" alt="" class="loader-site">
			</div>
		</div>
	<div id="wrapper">
		<div class="topbar">
			<div class="container">
				 <div class="row">
						<div class="col-md-6 text-left">
						    <p><i class="fa fa-graduation-cap"></i> Getting Closer To God</p>
						</div>
						<div class="col-md-6 text-right">
							<ul class="list-inline">
								<li>
									<a class="social" href="#"><i class="fa fa-facebook"></i></a>
									<a class="social" href="#"><i class="fa fa-twitter"></i></a>
									<a class="social" href="#"><i class="fa fa-google-plus"></i></a>
									<a class="social" href="#"><i class="fa fa-linkedin"></i></a>
								</li>
								<li class="dropdown">
									<a class="dropdown-toggle" href="#" data-toggle="dropdown"><i class="fa fa-lock"></i> Login & Register</a>
									<div class="dropdown-menu">
									  <form method="post">
									    <div class="form-title">
										<h4>Login Area</h4>
										<hr>
										</div>
										<input class="form-control" type="text" name="username" placeholder="User Name">
										<div class="formpassword">
										<input class="form-control" type="password" name="password" placeholder="******">
										</div>
										<div class="clearfix"></div>
										<button type="submit" class="btn btn-block btn-primary">Login</button>
										<hr>
										<h4><a href="#">Create an Account</a></h4>
									   </form>
									</div>
								</li>
							</ul>
						</div>
				  </div>
			</div>
		</div>
	<header class="header">
		<div class="container">
				<div class="hovermenu ttmenu">
				<div class="navbar navbar-default" role="navigation">
				<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="fa fa-bars"></span>
				</button>
				<div class="logo">
				<a class="navbar-brand" href="index-2.html"><img src="images/logo.png" width="120" height="60" alt=""></a>
				</div>
				</div>
				<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
				<li class="dropdown ttmenu-half"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Home</a>

				</li>
				<li><a href="http://localhost:8888/learn?page=page-about" data-load="?page=page-about">About</a></li>
				<li class="dropdown ttmenu-half"><a href="index.php"  data-toggle="dropdown" class="dropdown-toggle">Courses <b class="fa fa-angle-down"></b></a>
				<ul class="dropdown-menu">
				<li>
				<div class="ttmenu-content">
				<div class="row">
				<div class="col-md-6">
				<div class="box">
				<ul>
				<li><a href="course-list.html">Courses List</a></li>
				<li><a href="http://localhost:8888/learn?page=coursesGrid">Courses Grid</a></li>
				<li><a href="course-filterable.html">Courses Filterable</a></li>
				<li><a href="course-single.html">Single Course</a></li>
				<li><a href="course-quiz.html">Take a Quiz</a></li>
				<li><a href="course-achievements.html">Achievements</a></li>
				</ul>
				</div>
				</div>
				
				</div>
				<hr>
				<div class="row">
				<div class="col-md-3 col-sm-6 nopadding">
				<img class="img-thumbnail" src="upload/xservice_01.png.pagespeed.ic.2iuJZT3CaV.png" alt="">
				</div>
				<div class="col-md-3 col-sm-6 nopadding">
				<img class="img-thumbnail" src="upload/xservice_02.png.pagespeed.ic.c6RThoxSWC.png" alt="">
				</div>
				<div class="col-md-3 col-sm-6 nopadding">
				<img class="img-thumbnail" src="upload/xservice_03.png.pagespeed.ic.E_Ew4wn4ZP.png" alt="">
				</div>
				<div class="col-md-3 col-sm-6 nopadding">
				<img class="img-thumbnail" src="upload/xservice_04.png.pagespeed.ic.NGi9jRXTXk.png" alt="">
				</div>
				</div>
				</div>
				</li>
				</ul>
				</li>
				<li><a href="page-contact.html">Contact</a></li>
				<li><a class="btn btn-primary" href="course-login.html"><i class="fa fa-sign-in"></i> Register Now</a></li>
				</ul>
				
				</div>
				</div>
				</div>
				</div>
				</header>