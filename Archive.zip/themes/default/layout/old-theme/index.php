<?php require_once('head.php'); 


 require_once('header.php'); 

		$loadContent = $_GET['page'];


		if ($loadContent == 'page-about'){

			 
		     require_once('page-about.php'); 
		} else if ($loadContent == 'coursesGrid'){

			 
		     require_once('course-grid.php'); 
		}
		else {

			require_once('home-slider.php'); 
			 
		} 



 require_once('footer.php'); 
 require_once('copyrights.php'); 	
require_once('footer-js.php'); 




