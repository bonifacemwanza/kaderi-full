<section class="copyright">
						<div class="container">
						  <div class="row">
							 <div class="col-md-6 text-left">
									<p><a target="_blank" href="https://www.templateshub.net">Templates Hub</a></p>
							 </div>
							 <div class="col-md-6 text-right">
								 <ul class="list-inline">
									<li><a href="#">Terms of Usage</a></li>
									<li><a href="#">Privacy Policy</a></li>
									<li><a href="#">Sitemap</a></li>
								</ul>
							 </div>
						  </div>
						</div>
				</section>
		</div>